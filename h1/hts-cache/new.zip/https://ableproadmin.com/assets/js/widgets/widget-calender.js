'use strict';
document.addEventListener('DOMContentLoaded', function () {
  const datepicker_inline = new Datepicker(document.querySelector('#pc-datepicker-6'), {
    buttonClass: 'btn'
  });
});
